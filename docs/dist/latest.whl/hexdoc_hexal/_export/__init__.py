__resources__: list[str] = ["resources", "generated"]
