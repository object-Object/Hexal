from hexdoc.patchouli.page import Page


class EverbookEntryPage(Page, type="hexcasting:everbook_entry"):
    pass
