from hexdoc.plugin import hookimpl
from hexdoc_hexal.__gradle_version__ import GRADLE_VERSION


@hookimpl
def hexdoc_mod_version():
    return GRADLE_VERSION
