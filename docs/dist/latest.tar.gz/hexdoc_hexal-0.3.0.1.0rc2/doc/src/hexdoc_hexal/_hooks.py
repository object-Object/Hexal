from hexdoc.plugin import (
    LoadResourceDirsImpl,
    LoadTaggedUnionsImpl,
    ModVersionImpl,
    hookimpl,
)

from . import pages
from .__gradle_version__ import GRADLE_VERSION


class HexalPlugin(ModVersionImpl, LoadResourceDirsImpl, LoadTaggedUnionsImpl):
    @staticmethod
    @hookimpl
    def hexdoc_mod_version():
        return GRADLE_VERSION

    @staticmethod
    @hookimpl
    def hexdoc_load_resource_dirs():
        import hexdoc_hexal._export.generated

        return hexdoc_hexal._export.generated

    @staticmethod
    @hookimpl
    def hexdoc_load_tagged_unions():
        return pages
