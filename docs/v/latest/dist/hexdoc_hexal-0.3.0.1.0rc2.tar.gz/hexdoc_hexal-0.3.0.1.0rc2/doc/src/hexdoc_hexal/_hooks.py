from importlib.resources import Package

import hexdoc_hexal
from hexdoc.plugin import (
    HookReturn,
    LoadJinjaTemplatesImpl,
    LoadResourceDirsImpl,
    LoadTaggedUnionsImpl,
    ModVersionImpl,
    hookimpl,
)

from . import pages
from .__gradle_version__ import GRADLE_VERSION


class HexalPlugin(
    ModVersionImpl,
    LoadResourceDirsImpl,
    LoadTaggedUnionsImpl,
    LoadJinjaTemplatesImpl,
):
    @staticmethod
    @hookimpl
    def hexdoc_mod_version():
        return GRADLE_VERSION

    @staticmethod
    @hookimpl
    def hexdoc_load_resource_dirs():
        from hexdoc_hexal._export import generated

        return generated

    @staticmethod
    @hookimpl
    def hexdoc_load_tagged_unions():
        return pages

    @staticmethod
    @hookimpl
    def hexdoc_load_jinja_templates() -> HookReturn[tuple[Package, str]]:
        return hexdoc_hexal, "_templates"
